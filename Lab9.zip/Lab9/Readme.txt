In lab9, I use both Jquery and Javascript to update my homepage.html and let it can be checked in the localhost. Also I update the lab9jsontemplate.json to all of my html for each labs.

GitHub: RyanLil-Xvx 
repo name: iit
discord handle: qinh2#8689 & 882397570662543432