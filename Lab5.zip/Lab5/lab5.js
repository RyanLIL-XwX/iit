/* Lab 5 JavaScript File 
   Place variables and functions in this file */

function validate(formObj) {
   var focusSet=0;
   var alertText ="";
   // put your validation code here
   // it will be a series of if statements
   if (formObj.firstName.value === "") {
      alertText += "You must enter your first name\n";
      if (focusSet === 0){
         formObj.firstName.focus();
         focusSet = 1;
      }
      //return false;
   }

   if (formObj.lastName.value == "") {
      alertText += "You must enter your last name\n";
      if (focusSet === 0){
         formObj.lastName.focus();
         focusSet = 1;
      }
      //return false;
   }

   if (formObj.title.value == "") {
      alertText += "You must enter a title\n";
      if (focusSet === 0){
         formObj.title.focus();
         focusSet = 1;
      }
      //return false;
   }

   if (formObj.org.value == "") {
      alertText += "You must enter your organization\n";
      if (focusSet === 0){
         formObj.org.focus();
         focusSet = 1;
      }
      //return false;
   }

   if (formObj.nickname.value == "") {
      alertText += "You must enter your nickname\n";
      if (focusSet === 0){
         formObj.nickname.focus();
         focusSet = 1;
      }
     //return false
   }
 
   if (formObj.comments.value == "") {
      alertText += "You must enter the comments\n";
      if (focusSet === 0){
         formObj.comments.focus();
         focusSet = 1;
      }
      //return false;
   }
}

function bool(comments){
   if (comments.value === "Please enter your comments"){
      comments.value = "";
   }
}

function Click(){
   var formObj = document.getElementById("addForm");
   alert(formObj.firstName.value+" "+formObj.lastName.value+" is "+formObj.pseudonym.value);
}









