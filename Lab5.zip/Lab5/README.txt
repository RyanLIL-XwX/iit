	For the lab5, i add some elements in the lab5.css, lab5.html and the lab5.js. Expecially, for the 
lab5.js, i use the boolean variable to every function. So the logic for the lab5.js is that all the boxes on the website is required, so if someone did not write anything in the boxes, we will return a false variable. After that it will alert some text on the website. 
	For the lab5.html, i just add "for" in all the input part, and then use the onclick with the function 
called Click() i wrote in the javascript file. In this way, it will shoes the alertText after we click the button on the website.
	For the lab5.css, i just add two parts in the last for changing their background-color. One is the
comments, and another one is for the input content.