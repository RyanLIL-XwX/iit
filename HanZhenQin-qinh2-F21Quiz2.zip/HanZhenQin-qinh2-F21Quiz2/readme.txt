	In the first part of the quiz2, i update my project page(HanZhen_Qin_homepage.html), i add a 
javascript file to combine with the html, which is the jquery of javascript. i add three effects and one interaction in my homepage.html. First effect is the click function, which can show on the website. So under each lab's name, it have a info button, and when i click that button, it will show me the information about every different labs. Second and the third effects are the hide and show effects. Therefore, there are two buttons on the website. If i click the Hide Text, it will hide all the descriptive information on the website. If i click the Show Text, it will show all the contents we hided before. For the interaction part, i choose the sortable one, hence this interaction can make my website looked more clearly and tidy. 
	Alternatively, i use the jquery widgets the menu's format to correct the link part, to put the guidline in the top place, and all the files in the behind.

GitHub: RyanLil-Xvx 
repo name: iit
discord handle: qinh2#8689 & 882397570662543432